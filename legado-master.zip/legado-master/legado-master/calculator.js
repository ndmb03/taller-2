// MODULO DE CALCULADORA v5 - REFACTORIZADO (Patrón Strategy)
var buffer = "0";
var memoria = 0;
var ultimo_operador;
var historial = [];

var MAX_HISTORIAL_LENGTH = 5;

// REFACTOR (Strategy Pattern):
// Tarea solucionada. Objeto 'OPERATIONS' creado.
// (Usamos 'var' en lugar de 'const' para mantener la compatibilidad ES5)
var OPERATIONS = {
  '+': function(a, b) { return a + b; },
  '-': function(a, b) { return a - b; },
  '*': function(a, b) { return a * b; },
  '/': function(a, b) { return a / b; }
};

// REFACTOR (DRY): Función única para manejar la lógica del historial
function logToHistory(logEntry) {
  historial.push(logEntry);
  if (historial.length > MAX_HISTORIAL_LENGTH) {
    historial.shift();
  }
  console.log(historial);
}


function handleNumber(numStr) {
  if (buffer === "0") { buffer = numStr; } else { buffer += numStr; }
  updateScreen();
}

function handleSymbol(symbol) {
  var logEntry;

  switch (symbol) {
    case 'C':
      buffer = "0"; memoria = 0; ultimo_operador = null;
      break;
    case '=':
      if (ultimo_operador === null) { return; }

      var intBuffer = parseInt(buffer);
      var operacionPrevia = ultimo_operador;
      var memoriaPrevia = memoria;
      flushOperation(intBuffer); // Llama a la nueva función (v5)
      
      logEntry = memoriaPrevia + " " + operacionPrevia + " " + intBuffer + " = " + memoria;
      logToHistory(logEntry);

      ultimo_operador = null;
      buffer = "" + memoria;
      memoria = 0;
      break;
    case '+': case '-': case '*': case '/':
      handleMath(symbol);
      break;
  }
  updateScreen();
}

function handleMath(symbol) {
  if (buffer === '0' && memoria === 0) { return; }
  var intBuffer = parseInt(buffer);
  if (memoria === 0) {
    memoria = intBuffer;
  } else {
      var operacionPrevia = ultimo_operador;
      var memoriaPrevia = memoria;
      flushOperation(intBuffer); // Llama a la nueva función (v5)
      
      var logEntry = memoriaPrevia + " " + operacionPrevia + " " + intBuffer + " = " + memoria;
      logToHistory(logEntry);
  }
  ultimo_operador = symbol;
  buffer = "0";
}

// REFACTOR (Strategy Pattern):
// Tarea solucionada. El 'if-else' gigante ha sido reemplazado.
// La complejidad ciclomática de esta función ahora es 2 (mucho más baja).
function flushOperation(intBuffer) {
  if (OPERATIONS[ultimo_operador]) {
    memoria = OPERATIONS[ultimo_operador](memoria, intBuffer);
  }
}

function updateScreen(){
  document.getElementById("display").innerText = buffer;
}

function init(){
  document.querySelector('.buttons').addEventListener('click', function(event) {
    buttonClick(event.target.innerText);
  });
}
function buttonClick(value) {
  if (isNaN(parseInt(value))) { handleSymbol(value); } else { handleNumber(value); }
}
init();